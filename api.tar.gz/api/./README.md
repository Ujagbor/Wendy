# Devops API App


### install the node packages for the api tier:
```sh
→ npm install
```

### start the app
```sh
→ npm start
```

###  NOTE this app uses two env variables:

- PORT: the listening PORT
- DB_USER
- DB_HOST
- DB_NAME
- DB_PASSWORD
- DB_PORT

